<?php defined('SYSPATH') or die('No direct script access.');
/**
 * Very basic French translation of the Admin Map plugin
 *
 * @author     John Etherton <john@ethertontech.com>
 * @package    Enhanced Map, Ushahidi Plugin - https://github.com/jetherton/enhancedmap
 */

	$lang = array(
	'big_map_main_menu_tab' => 'Carte de Grande',
	'boolean_operators' => 'Operateurs booleens',
	'status_filters' => 'Filtres Statut',
	);
?>
