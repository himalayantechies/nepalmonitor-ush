<?php defined('SYSPATH') OR die('No direct access allowed.');

    /*
    * You need to provide your pubid from your Add This account. This
    *    id will allow you to track the shares from the plugin onto
    *    the different social networks. You can find this ID by getting
    *    and embed code from Add This and looking at the JavaScript
    *    where it says, "pubid=XXXXXXX" in the URL of the javascript
    *    file. Be sure to include that entire variable.
    */

    $config['pubid'] = '';
?>
