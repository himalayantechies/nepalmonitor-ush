=== About ===
name: Add This
website: http://www.brianherbert.com
description: Adds links on the deployment so users can share reports on Facebook, Twitter and others using the Add This service.
version: 0.1
requires: 2.1
tested up to: 2.5
author: Brian Herbert
author website: http://www.ushahidi.com

== Description ==
Adds links on the deployment so users can share reports on Facebook, Twitter and others using the Add This service.

== Installation ==
1. Copy the entire /addthis/ directory into your /plugins/ directory.
2. Add your pubid in the /addthis/config/addthis.php file, found when you get an embed code on addthis.com
3. Activate the plugin.

== Changelog ==