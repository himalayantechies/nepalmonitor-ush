=== About ===
name: Link Reports
website: http://apps.ushahidi.com
description: Lets you setup links between two different reports
version: 1.0
requires: 2.1
tested up to: 2.1
author: John Etherton
author website: http://johnetherton.com

== Description ==
Lets you create hyper links between two reports. This way if report A is related to report B, you can easily add a link to them.
