<?php
	$lang = array(
		'link_to_other_reports'=>'Link to Other Reports',
		'link_to_report'=>'Link to report',
		'add'=>"Add",
		'remove'=>"Remove",
		'report_links_from'=>'This report links to these reports:',
		'report_links_to'=>'These reports link to this report:',
	);
?>
