<?php defined('SYSPATH') or die('No direct script access.');
/**
* Model for linkreports
 *
 * PHP version 5
 * @author     John Etherton <john@ethertontech.com> 
 * @module     linkreports Model  
 */

class Linkreports_Model extends ORM
{
	
	// Database table name
	protected $table_name = 'linkreports';
}
