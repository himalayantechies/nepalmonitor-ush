<?php
	$lang = array(
		'category'=>'Seleziona almeno una categoria',
		'from_date'=>'Inserisci una data DA valida',
		'to_date'=>'Inserisci una data A valida',
		'required'=>'Questo campo è obbligatorio',
	);
?>
