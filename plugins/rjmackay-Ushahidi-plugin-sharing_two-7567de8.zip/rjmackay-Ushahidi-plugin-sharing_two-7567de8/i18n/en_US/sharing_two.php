<?php
$lang = array(
	'all_sites' => 'All Sites',
	'site_filter' => 'Site Filter',
);
