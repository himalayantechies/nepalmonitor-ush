<?php defined('SYSPATH') or die('No direct script access.');
/**
 * Where all the work is done. This file handles map rendering requests and requests for Geo JSON
 * 
 * This file is adapted from the file Ushahidi_Web/appliction/controllers/json.php and
 * Ushahidi_Web/application/controllers/main.php
 * Originally written by the Ushahidi Team
 *
 * PHP version 5
 * LICENSE: This source file is subject to LGPL license
 * that is available through the world-wide-web at the following URI:
 * http://www.gnu.org/copyleft/lesser.html
 * @author     John Etherton <john@ethertontech.com>
 * @package    Admin Map - https://github.com/jetherton/adminmap
 */
class adminmap_helper_Core {

	// Table Prefix
	protected static $table_prefix;

	static function init()
	{
		// Set Table Prefix
		self::$table_prefix = Kohana::config('database.default.table_prefix');
	}

	/**************************************************************************************************************
      * Given all the parameters returns a list of incidents that meet the search criteria
      */
	public static function setup_adminmap($map_controller, $map_view = "adminmap/mapview", $map_css = "adminmap/css/adminmap")		
	{
	
		//set the CSS for this
		if($map_css != null)
		{
			plugin::add_stylesheet($map_css);
		}
		
		plugin::add_javascript("adminmap/js/jquery.flot");
		plugin::add_javascript("adminmap/js/excanvas.min");
		plugin::add_javascript("adminmap/js/timeline");
		plugin::add_javascript("adminmap/js/jquery.hovertip-1.0");
		
		$map_controller->template->content = new View($map_view);
		
		// Get Default Color
		$map_controller->template->content->default_map_all = Kohana::config('settings.default_map_all');
	}
	
	
	/****
	* Sets up the overlays and shares
	*/
	public static function set_overlays_shares($map_controller)
	{
				// Get all active Layers (KMZ/KML)
		$layers = array();
		$config_layers = Kohana::config('map.layers'); // use config/map layers if set
		if ($config_layers == $layers) {
			foreach (ORM::factory('layer')
					  ->where('layer_visible', 1)
					  ->find_all() as $layer)
			{
				$layers[$layer->id] = array($layer->layer_name, $layer->layer_color,
					$layer->layer_url, $layer->layer_file);
			}
		} else {
			$layers = $config_layers;
		}
		$map_controller->template->content->layers = $layers;

		// Get all active Shares
		$shares = array();
		/*
		foreach (ORM::factory('sharing')
				  ->where('sharing_active', 1)
				  ->find_all() as $share)
		{
			$shares[$share->id] = array($share->sharing_name, $share->sharing_color);
		}
		*/
		$map_controller->template->content->shares = $shares;
	}
	
	
	/*
	* this makes the map for this plugin
	*/
	public static function set_map($template, $themes, $json_url, $json_timeline_url, $javascript_view = 'adminmap/adminmap_js',
							$div_map_view = 'adminmap/main_map', $div_timeline_view = 'adminmap/main_timeline', $urlParams = array())
	{
		
		//are we on the backend?
		$on_back_end = false;
		if (stripos($json_url, 'admin/') === 0)
		{
			$on_back_end = true;	
		}
	
		////////////////////////////////////////////////////////////////Map and Slider Blocks////////////////////////////////////////////////////////////////////////////
		$div_map = new View($div_map_view);
		$div_timeline = new View($div_timeline_view);
			// Filter::map_main - Modify Main Map Block
			Event::run('ushahidi_filter.map_main', $div_map);
			// Filter::map_timeline - Modify Main Map Block
			Event::run('ushahidi_filter.map_timeline', $div_timeline);
		$template->content->div_map = $div_map;
		$template->content->div_timeline = $div_timeline;

	
		///////////////////////////////////////////////////////////////SETUP THE DATES////////////////////////////////////////////////////////////////////////////
        // Get The START, END and Incident Dates
        $startDate = "";
		$endDate = "";
		$display_startDate = 0;
		$display_endDate = 0;

		$db = new Database();
        // Next, Get the Range of Years
		$query = $db->query('SELECT DATE_FORMAT(incident_date, \'%Y-%c\') AS dates FROM '.self::$table_prefix.'incident WHERE incident_active = 1 GROUP BY DATE_FORMAT(incident_date, \'%Y-%c\') ORDER BY incident_date');

		$first_year = date('Y');
		$last_year = date('Y');
		$first_month = 1;
		$last_month = 12;
		$i = 0;

		foreach ($query as $data)
		{
			$date = explode('-',$data->dates);

			$year = $date[0];
			$month = $date[1];

			// Set first year
			if($i == 0)
			{
				$first_year = $year;
				$first_month = $month;
			}

			// Set last dates
			$last_year = $year;
			$last_month = $month;

			$i++;
		}

		$show_year = $first_year;
		$selected_start_flag = TRUE;
		while($show_year <= $last_year)
		{
			$startDate .= "<optgroup label=\"".$show_year."\">";

			$s_m = 1;
			if($show_year == $first_year)
			{
				// If we are showing the first year, the starting month may not be January
				$s_m = $first_month;
			}

			$l_m = 12;
			if($show_year == $last_year)
			{
				// If we are showing the last year, the ending month may not be December
				$l_m = $last_month;
			}

			for ( $i=$s_m; $i <= $l_m; $i++ )
			{
				if ( $i < 10 )
				{
					// All months need to be two digits
					$i = "0".$i;
				}
				$startDate .= "<option value=\"".strtotime($show_year."-".$i."-01")."\"";
				if($selected_start_flag == TRUE)
				{
					$display_startDate = strtotime($show_year."-".$i."-01");
					$startDate .= " selected=\"selected\" ";
					$selected_start_flag = FALSE;
				}
				$startDate .= ">".date('M', mktime(0,0,0,$i,1))." ".$show_year."</option>";
			}
			$startDate .= "</optgroup>";

			$endDate .= "<optgroup label=\"".$show_year."\">";
			for ( $i=$s_m; $i <= $l_m; $i++ )
			{
				if ( $i < 10 )
				{
					// All months need to be two digits
					$i = "0".$i;
				}
				$endDate .= "<option value=\"".strtotime($show_year."-".$i."-".date('t', mktime(0,0,0,$i,1))." 23:59:59")."\"";

                if($i == $l_m AND $show_year == $last_year)
				{
					$display_endDate = strtotime($show_year."-".$i."-".date('t', mktime(0,0,0,$i,1))." 23:59:59");
					$endDate .= " selected=\"selected\" ";
				}
				$endDate .= ">".date('M', mktime(0,0,0,$i,1))." ".$show_year."</option>";
			}
			$endDate .= "</optgroup>";

			// Show next year
			$show_year++;
		}

		Event::run('ushahidi_filter.active_startDate', $display_startDate);
		Event::run('ushahidi_filter.active_endDate', $display_endDate);
		Event::run('ushahidi_filter.startDate', $startDate);
		Event::run('ushahidi_filter.endDate', $endDate);
		
		$template->content->div_timeline->startDate = $startDate;
		$template->content->div_timeline->endDate = $endDate;
		///////////////////////////////////////////////////////////////MAP JAVA SCRIPT////////////////////////////////////////////////////////////////////////////
		
		//turn the map on, also turn on the timeline
		//$template->flot_enabled = TRUE; //this is done using our own custom .js files in the adminmap/js folder.
		$themes->map_enabled = true;
		
		//check if we're on the front end, if we are then the template and themese will be different
		if($themes != $template)
		{
			$themes->main_page = true;
		}
		
		$themes->js = new View($javascript_view);
		$themes->js->urlParams = $urlParams;
		$themes->js->default_map = Kohana::config('settings.default_map');
		$themes->js->default_zoom = Kohana::config('settings.default_zoom');
		if($on_back_end)
		{
			$themes->js->show_unapproved = '3';	
		}
		

		// Map Settings
		$clustering = Kohana::config('settings.allow_clustering');
		$marker_radius = Kohana::config('map.marker_radius');
		$marker_opacity = Kohana::config('map.marker_opacity');
		$marker_stroke_width = Kohana::config('map.marker_stroke_width');
		$marker_stroke_opacity = Kohana::config('map.marker_stroke_opacity');

		// pdestefanis - allows to restrict the number of zoomlevels available
		$numZoomLevels = Kohana::config('map.numZoomLevels');
		$minZoomLevel = Kohana::config('map.minZoomLevel');
	   	$maxZoomLevel = Kohana::config('map.maxZoomLevel');

		// pdestefanis - allows to limit the extents of the map
		$lonFrom = Kohana::config('map.lonFrom');
		$latFrom = Kohana::config('map.latFrom');
		$lonTo = Kohana::config('map.lonTo');
		$latTo = Kohana::config('map.latTo');

		
		$themes->js->json_url = $json_url;
		$themes->js->json_timeline_url  = $json_timeline_url;
		$themes->js->marker_radius =
			($marker_radius >=1 && $marker_radius <= 10 ) ? $marker_radius : 5;
		$themes->js->marker_opacity =
			($marker_opacity >=1 && $marker_opacity <= 10 )
			? $marker_opacity * 0.1  : 0.9;
		$themes->js->marker_stroke_width =
			($marker_stroke_width >=1 && $marker_stroke_width <= 5 ) ? $marker_stroke_width : 2;
		$themes->js->marker_stroke_opacity =
			($marker_stroke_opacity >=1 && $marker_stroke_opacity <= 10 )
			? $marker_stroke_opacity * 0.1  : 0.9;

		// pdestefanis - allows to restrict the number of zoomlevels available
		$themes->js->numZoomLevels = $numZoomLevels;
		$themes->js->minZoomLevel = $minZoomLevel;
		$themes->js->maxZoomLevel = $maxZoomLevel;

		// pdestefanis - allows to limit the extents of the map
		$themes->js->lonFrom = $lonFrom;
		$themes->js->latFrom = $latFrom;
		$themes->js->lonTo = $lonTo;
		$themes->js->latTo = $latTo;

		$themes->js->default_map = Kohana::config('settings.default_map');
		$themes->js->default_zoom = Kohana::config('settings.default_zoom');
		$themes->js->latitude = Kohana::config('settings.default_lat');
		$themes->js->longitude = Kohana::config('settings.default_lon');
		$themes->js->default_map_all = Kohana::config('settings.default_map_all');
		$themes->js->active_startDate = $display_startDate;
		$themes->js->active_endDate = $display_endDate;
		


	}
	
	public static function set_categories($map_controller, $on_backend = false, $group = false)
	{
	
		// Check for localization of parent category
		// Get locale
		$l = Kohana::config('locale.language.0');
	
		$parent_categories = array();
	
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		//Check to see if we're dealing with a group, and thus
		//should show group specific categories
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		if($group != false)
		{
			//check and make sure the simpel groups category is installed
			$plugin = ORM::factory('plugin')
				->where('plugin_name', 'simplegroups')
				->where('plugin_active', '1')
				->find();
			if(!$plugin)
			{
				throw new Exception("A group was set in adminmap_helper::set_categories() when the SimpleGroupl plugin is not installed");
			}
		
			$cats = ORM::factory('simplegroups_category');
			if(!$on_backend)
			{	
				$cats = $cats->where('category_visible', '1');
			}
			$cats = $cats->where('parent_id', '0');
			$cats = $cats->where('applies_to_report', 1);
			$cats = $cats->where('simplegroups_groups_id', $group->id)
				->find_all() ;
			foreach ($cats as $category)
			{				
				/////////////////////////////////////////////////////////////////////////////////////////////
				// Get the children
				/////////////////////////////////////////////////////////////////////////////////////////////
				$children = array();
				foreach ($category->children as $child)
				{
					// Check for localization of child category

					$translated_title = Simplegroups_category_lang_Model::simplegroups_category_title($child->id,$l);

					if($translated_title)
					{
						$display_title = $translated_title;
					}
					else
					{
						$display_title = $child->category_title;
					}

					$children["sg_".$child->id] = array(
						$display_title,
						$child->category_color,
						$child->category_image
					);
					
				}

				

				$translated_title = Simplegroups_category_lang_Model::simplegroups_category_title($category->id,$l);

				if($translated_title)
				{
					$display_title = $translated_title;
				}else{
					$display_title = $category->category_title;
				}

				// Put it all together				
				$parent_categories["sg_".$category->id] = array(
					$display_title,
					$category->category_color,
					$category->category_image,
					$children
				);				
			}
		}

		/////////////////////////////////////////////////////////////////////////////////////////////
        // Get all active top level categories
		/////////////////////////////////////////////////////////////////////////////////////////////
		
		$cats = ORM::factory('category');
		if(!$on_backend)
		{	
			$cats = $cats->where('category_visible', '1');
		}
		$cats = $cats->where('parent_id', '0')
			->orderby('category_position', 'asc')		
			->find_all() ;
		foreach ($cats as $category)
		{
			/////////////////////////////////////////////////////////////////////////////////////////////
			// Get the children
			/////////////////////////////////////////////////////////////////////////////////////////////
			$children = array();
			foreach ($category->children as $child)
			{
				// Check for localization of child category

				$translated_title = Category_Lang_Model::category_title($child->id,$l);

				if($translated_title)
				{
					$display_title = $translated_title;
				}
				else
				{
					$display_title = $child->category_title;
				}

				$children[$child->id] = array(
					$display_title,
					$child->category_color,
					$child->category_image
				);

				if ($child->category_trusted)
				{ // Get Trusted Category Count
					$trusted = ORM::factory("incident")
						->join("incident_category","incident.id","incident_category.incident_id")
						->where("category_id",$child->id);
					if ( ! $trusted->count_all())
					{
						unset($children[$child->id]);
					}
				}
			}

			

			$translated_title = Category_Lang_Model::category_title($category->id,$l);

			if($translated_title)
			{
				$display_title = $translated_title;
			}else{
				$display_title = $category->category_title;
			}

			// Put it all together
			$parent_categories[$category->id] = array(
				$display_title,
				$category->category_color,
				$category->category_image,
				$children
			);

			if ($category->category_trusted)
			{ // Get Trusted Category Count
				$trusted = ORM::factory("incident")
					->join("incident_category","incident.id","incident_category.incident_id")
					->where("category_id",$category->id);
				if ( ! $trusted->count_all())
				{
					unset($parent_categories[$category->id]);
				}
			}
		}
		
		
		
		
		$map_controller->template->content->categories = $parent_categories;
	}//end method
	
	
	



	/////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////METHODS FOR the JSON CONTROLLER
	///////////////////////////////////////////////////////////////////////////////////////////////////
	
	
	/**
	* Generate JSON in NON-CLUSTER mode
	* $edit_report_path is used to set where the link to edit/view a report should be set to
	* $on_the_back_end sets whether or not this user is viewing this data from the backend
	*/
	public static function json_index($json_controller,  $on_the_back_end = true,
		$link_target = "_self",
		$link_path_prefix = '')
	{
		$json = "";
		$json_item = "";
		$json_array = array();		
		$icon = "";

		$media_type = (isset($_GET['m']) AND intval($_GET['m']) > 0)? intval($_GET['m']) : 0;
		
		// Get the incident and category id
		$category_id = (isset($_GET['c']) AND is_array($_GET['c']))? $_GET['c'] : array('0');
		$incident_id = (isset($_GET['i']) AND intval($_GET['i']) > 0)? intval($_GET['i']) : 0;
		// Get the category colour
		if(count($category_id) == 1 AND intval($category_id[0]) == 0 )
		{
			$colors = array(Kohana::config('settings.default_map_all'));
		}
		
		else 
		{	
			//more than one color
			$colors = array();
			foreach($category_id as $cat)
			{
				$colors[] = ORM::factory('category', $cat)->category_color;
			}			
		}
		$color = self::merge_colors($colors);	
		
		//since we're on the back end, wana do anything special?
		$admin_path = '';
		$view_or_edit = 'view';
		if($on_the_back_end)
		{
			$admin_path = 'admin/';
			$view_or_edit = 'edit';
		}
		//set approve text
		$approved_text = "";
		if( $on_the_back_end)
		{
			//figure out if we're showing unapproved stuff or what.
			if (isset($_GET['u']) AND !empty($_GET['u']))
			{
			    $show_unapproved = (int) $_GET['u'];
			}		
			if($show_unapproved == 1)
			{
				$approved_text = "incident.incident_active = 1 ";
			}
			else if ($show_unapproved == 2)
			{
				$approved_text = "incident.incident_active = 0 ";
			}
			else if ($show_unapproved == 3)
			{
				$approved_text = " (incident.incident_active = 0 OR incident.incident_active = 1) ";
			}
		}
		else
		{
			$approved_text = "incident.incident_active = 1 ";
		}
		
		//Logical operator
		$logical_operator = isset($_GET['lo'])  ? $_GET['lo'] : 'or';
		
		$where_text = '';
		// Do we have a media id to filter by?
		if (isset($_GET['m']) AND !empty($_GET['m']) AND $_GET['m'] != '0')
		{
		    $media_type = (int) $_GET['m'];
		    $where_text .= " AND ".self::$table_prefix."media.media_type = " . $media_type;
		}

		if (isset($_GET['s']) AND !empty($_GET['s']))
		{
		    $start_date = (int) $_GET['s'];
		    $where_text .= " AND UNIX_TIMESTAMP(".self::$table_prefix."incident.incident_date) >= '" . $start_date . "'";
		}

		if (isset($_GET['e']) AND !empty($_GET['e']))
		{
		    $end_date = (int) $_GET['e'];
		    $where_text .= " AND UNIX_TIMESTAMP(".self::$table_prefix."incident.incident_date) <= '" . $end_date . "'";
		}
		
		// Fetch the incidents
		$markers = adminmap_reports::get_reports_list_by_cat($category_id, 
			$approved_text . '  '. $where_text,
			$logical_operator,
			"incident.id",
			"asc");
		
		// Variable to store individual item for report detail page
		$json_item_first = "";	
		foreach ($markers as $marker)
		{
			$thumb = "";
			
			
			$json_item = "{";
			$json_item .= "\"type\":\"Feature\",";
			$json_item .= "\"properties\": {";
			$json_item .= "\"id\": \"".$marker->id."\", \n";

			$encoded_title = utf8tohtml::convert($marker->incident_title, TRUE);
			$encoded_title = str_ireplace('"','&#34;',$encoded_title);
			$encoded_title = json_encode($encoded_title);
			$encoded_title = str_ireplace('"', '', $encoded_title);

			$json_item .= "\"name\":\"" . str_replace(chr(10), ' ', str_replace(chr(13), ' ', "<a target = '".$link_target
					. "' href='".url::base().$admin_path.$link_path_prefix."reports/".$view_or_edit."/".$marker->id."'>".$encoded_title)."</a>") . "\","
					. "\"link\": \"".url::base().$admin_path.$link_path_prefix."reports/".$view_or_edit."/".$marker->id."\", ";

			$json_item .= (isset($category))
				? "\"category\":[" . $category_id . "], "
				: "\"category\":[0], ";

			$json_item .= "\"color\": \"".$color."\", \n";
			$json_item .= "\"icon\": \"".$icon."\", \n";
			$json_item .= "\"thumb\": \"".$thumb."\", \n";
			$json_item .= "\"timestamp\": \"" . strtotime($marker->incident_date) . "\"";
			$json_item .= "},";
			$json_item .= "\"geometry\": {";
			$json_item .= "\"type\":\"Point\", ";
			$json_item .= "\"coordinates\":[" . $marker->lon . ", " . $marker->lat . "]";
			$json_item .= "}";
			$json_item .= "}";

			if ($marker->id == $incident_id)
			{
				$json_item_first = $json_item;
			}
			else
			{
				array_push($json_array, $json_item);
			}
			
			// Get Incident Geometries
			/* Slows things down too much
			$geometry = self::_get_geometry($marker->incident_id, $marker->incident_title, $marker->incident_date);
			if (count($geometry))
			{
				$json_item = implode(",", $geometry);
				array_push($json_array, $json_item);
			}
			*/
		}
		
		if ($json_item_first)
		{
			// Push individual marker in last so that it is layered on top when pulled into map
			array_push($json_array, $json_item_first);
		}
		
		$json = implode(",", $json_array);

		header('Content-type: application/json; charset=utf-8');
		$json_controller->template->json = '{"type":"FeatureCollection","features":['.$json.']}';
	}
	
	
	
	
	
	
	



/************************************************************************************************
	* Function, this'll merge colors. Given an array of category IDs it'll return a hex string
	* of all the colors merged together
	*/
	public static function merge_colors($colors)
	{
		//check if we're dealing with just one color
		if(count($colors)==1)
		{
			foreach($colors as $color)
			{
				Event::run('adminmap_filter.features_color', $color);
				return $color;
			}
		}
		//now for each color break it into RGB, add them up, then normalize
		$red = 0;
		$green = 0;
		$blue = 0;
		foreach($colors as $color)
		{
			$numeric_colors = self::_hex2RGB($color);
			$red = $red + $numeric_colors['red'];
			$green = $green + $numeric_colors['green'];
			$blue = $blue + $numeric_colors['blue'];
		}
		//now normalize
		$color_length = sqrt( ($red*$red) + ($green*$green) + ($blue*$blue));
	
		//make sure there's no divide by zero
		if($color_length == 0)
		{
			$color_length = 255;
		}
		$red = ($red / $color_length) * 255;
		$green = ($green / $color_length) * 255;
		$blue = ($blue / $color_length) * 255;
	
		
		//pad with zeros if there's too much space
		$red = dechex($red);
		if(strlen($red) < 2)
		{
			$red = "0".$red;
		}
		$green = dechex($green);
		if(strlen($green) < 2)
		{
			$green = "0".$green;
		}
		$blue = dechex($blue);
		if(strlen($blue) < 2)
		{
			$blue = "0".$blue;
		}
		//now put the color back together and return it
		$color_str = $red.$green.$blue;
		//in case other plugins have something to say about this
		Event::run('adminmap_filter.features_color', $color_str);
		return $color_str;
		
	}//end method merge colors



	private static function _hex2RGB($hexStr, $returnAsString = false, $seperator = ',') 
	{
		$hexStr = preg_replace("/[^0-9A-Fa-f]/", '', $hexStr); // Gets a proper hex string
		$rgbArray = array();
		if (strlen($hexStr) == 6) 
		{ //If a proper hex code, convert using bitwise operation. No overhead... faster
			$colorVal = hexdec($hexStr);
			$rgbArray['red'] = 0xFF & ($colorVal >> 0x10);
			$rgbArray['green'] = 0xFF & ($colorVal >> 0x8);
			$rgbArray['blue'] = 0xFF & $colorVal;
		} 
		elseif (strlen($hexStr) == 3) 
		{ //if shorthand notation, need some string manipulations
			$rgbArray['red'] = hexdec(str_repeat(substr($hexStr, 0, 1), 2));
			$rgbArray['green'] = hexdec(str_repeat(substr($hexStr, 1, 1), 2));
			$rgbArray['blue'] = hexdec(str_repeat(substr($hexStr, 2, 1), 2));
		} 
		else 
		{
			return false; //Invalid hex color code
		}
		return $returnAsString ? implode($seperator, $rgbArray) : $rgbArray; // returns the rgb string or the associative array
	}







	
	
	

/***************************************************************************************************************
     * Generate JSON in CLUSTER mode
     * $edit_report_path sets the path to the link to edit/view a report
     * $list_report_path sets the path to view a cluster of reports
     * $on_the_back_end sets whether or not this user is looking at this from the front end or back end
     */
    public static function json_cluster($controller, 	
	$on_the_back_end = true,
	$link_target = "_self",
	$link_path_prefix = "")
    {
		// Database
		$db = new Database();

		$json = "";
		$json_item = "";
		$json_array = array();
		$geometry_array = array();

		
		$icon = "";

		// Get Zoom Level
		$zoomLevel = (isset($_GET['z']) AND !empty($_GET['z'])) ?
			(int) $_GET['z'] : 8;

		//$distance = 60;
		$distance = (10000000 >> $zoomLevel) / 100000;
		
   		
		// Category ID
		$category_ids = (isset($_GET['c']) AND is_array($_GET['c'])) ? $_GET['c'] : array(0);
		
		// Start date
		$start_date = (isset($_GET['s']) AND intval($_GET['s']) > 0) ? intval($_GET['s']) : NULL;
		
		// End date
		$end_date = (isset($_GET['e']) AND intval($_GET['e']) > 0) ? intval($_GET['e']) : NULL;
		
		//Logical operator
		$logical_operator = isset($_GET['lo'])  ? $_GET['lo'] : 'or';
		
		 // SouthWest Bound
	        $southwest = (isset($_GET['sw']) AND !empty($_GET['sw'])) ?
	            $_GET['sw'] : "0";
	
	        $northeast = (isset($_GET['ne']) AND !empty($_GET['ne'])) ?
	            $_GET['ne'] : "0";
	
		
		//approve filter
		if($on_the_back_end)
		{
			//figure out if we're showing unapproved stuff or what.
			if (isset($_GET['u']) AND !empty($_GET['u']))
			{
			    $show_unapproved = (int) $_GET['u'];
			}
			$approved_text = "";
			if($show_unapproved == 1)
			{
				$approved_text = "incident.incident_active = 1 ";
			}
			else if ($show_unapproved == 2)
			{
				$approved_text = "incident.incident_active = 0 ";
			}
			else if ($show_unapproved == 3)
			{
				$approved_text = " (incident.incident_active = 0 OR incident.incident_active = 1) ";
			}	
		}
		else
		{
			$approved_text = "incident.incident_active = 1 ";
			$show_unapproved = 1;
		}
		
		//get color
  		if(count($category_ids) == 1 AND intval($category_ids[0]) == 0 )
		{
			$colors = array(Kohana::config('settings.default_map_all'));
		}		
		else 
		{	
			//more than one color
			$colors = array();
			foreach($category_ids as $cat)
			{
				$colors[] = ORM::factory('category', $cat)->category_color;
			}
		}
		$color = self::merge_colors($colors);	
		
		//make the filter text
		$filter = "";
	        $filter .= ($start_date) ?
	            " AND incident.incident_date >= '" . date("Y-m-d H:i:s", $start_date) . "'" : "";
	        $filter .= ($end_date) ?
	            " AND incident.incident_date <= '" . date("Y-m-d H:i:s", $end_date) . "'" : "";
	
	        if ($southwest AND $northeast)
	        {
	            list($latitude_min, $longitude_min) = explode(',', $southwest);
	            list($latitude_max, $longitude_max) = explode(',', $northeast);
	
	            $filter .= " AND location.latitude >=".(float) $latitude_min.
	                " AND location.latitude <=".(float) $latitude_max;
	            $filter .= " AND location.longitude >=".(float) $longitude_min.
	                " AND location.longitude <=".(float) $longitude_max;
	        }
	
		
		// Fetch the incidents using the specified parameters
		$incidents = adminmap_reports::get_reports_list_by_cat($category_ids, 
			$approved_text. ' ' .$filter ,
			$logical_operator,
			"incident.id",
			"asc");    
		
		/**
		 * **********************************************************************************************************************
		 * ********************************************************************************************************************** 
		 * We have the incidents, now process them
		 */

	
		// Create markers by marrying the the stuff together
		$markers = array();
		//read all the data into an array
		foreach($incidents as $incident)
		{
			$markers[$incident->id] = $incident;
		}
		

		$clusters = array();	// Clustered
		$singles = array();		// Non Clustered

		// Loop until all markers have been compared
		while (count($markers))
		{
			$marker  = array_pop($markers);
	        	//to keep track of the geometry of a cluster
	        	$lat = $marker->lat;
	        	$lon = $marker->lon;
	        	$north = $south = $marker->lat;
	        	$east = $west = $marker->lon;
	        	$count = 1;
	        	
			$cluster = array();
			// Compare marker against all remaining markers.
			foreach ($markers as $key => $target)
			{
				$pixels = abs($marker->lon - $target->lon) + abs($marker->lat - $target->lat);
					
				// If two markers are closer than defined distance, remove compareMarker from array and add to cluster.
				if ($pixels < $distance)
				{
					unset($markers[$key]);
					//update the gemetry
					$lat += $target->lat;
					$lon += $target->lon;
					if($target->lat < $south)
						$south = $target->lat;
					if($target->lat > $north)
						$north = $target->lat;
					if($target->lon < $west)
						$west = $target->lon;
					if($target->lon > $east)
						$east = $target->lon;
					$count++;
					
				}//end if the the two points are close
				//trying to minizmie memory use
				unset($target);
			}//end for loop

			// If a marker was added to cluster, also add the marker we were comparing to.
			//if (count($cluster) > 0)
			if ($count > 1)
			{
				$lat = $lat / $count;
				$lon = $lon / $count;
				//geometry
				$cluster['center'] = $lon.','.$lat;
				$cluster['sw'] = $west.','.$south;
				$cluster['ne'] = $east.','.$north;
				$cluster['count'] = $count;
				$clusters[] = $cluster;
			}
			//it's a loner
			else
			{
				$singles[] = $marker;
			}
		}
		
    	//since we're on the back end, wana do anything special?
		$admin_path = '';
		$view_or_edit = 'view';
		if($on_the_back_end)
		{
			$admin_path = 'admin/';
			$view_or_edit = 'edit';
		}

		// Create Json
		foreach ($clusters as $cluster)
		{
			// get cluster center
			$cluster_center = $cluster['center'];
			$southwest = $cluster['sw'];
			$northeast = $cluster['ne'];

			// Number of Items in Cluster
			$cluster_count = $cluster['count'];
			
		
			
			// Build out the JSON string
			$json_item = "{";
			$json_item .= "\"type\":\"Feature\",";
			$json_item .= "\"properties\": {";
			$json_item .= "\"name\":\"" . str_replace(chr(10), ' ', str_replace(chr(13), ' ', "<a target = ".$link_target." href=" . url::base().$admin_path.$link_path_prefix
				 . "reports/index/?".$_SERVER['QUERY_STRING']."&sw=".$southwest."&ne=".$northeast.">" . $cluster_count . " Reports</a>")) . "\",";
			$json_item .= "\"link\": \"".url::base().$admin_path.$link_path_prefix. "reports/index/?".$_SERVER['QUERY_STRING']."&sw=".$southwest."&ne=".$northeast."\", ";
			$json_item .= "\"category\":[0], ";
			$json_item .= "\"color\": \"".$color."\", ";
			$json_item .= "\"icon\": \"".$icon."\", ";
			$json_item .= "\"thumb\": \"\", ";
			$json_item .= "\"timestamp\": \"0\", ";
			$json_item .= "\"count\": \"" . $cluster_count . "\"";
			$json_item .= "},";
			$json_item .= "\"geometry\": {";
			$json_item .= "\"type\":\"Point\", ";
			$json_item .= "\"coordinates\":[" . $cluster_center . "]";
			$json_item .= "}";
			$json_item .= "}";

			array_push($json_array, $json_item);
		}

		foreach ($singles as $single)
		{
			$lon = $single->lon ? $single->lon : "0";
			$lat = $single->lat ? $single->lat : "0";
			
			$json_item = "{";
			$json_item .= "\"type\":\"Feature\",";
			$json_item .= "\"properties\": {";
			$json_item .= "\"name\":\"" . str_replace(chr(10), ' ', str_replace(chr(13), ' ', "<a target = ".$link_target." href=" . url::base().$admin_path.$link_path_prefix
					. "reports/".$view_or_edit."/" . $single->id . "/>".str_replace('"','\"',$single->incident_title)."</a>")) . "\",";
			$json_item .= "\"link\": \"".url::base().$admin_path.$link_path_prefix."reports/".$view_or_edit."/".$single->id."\", ";
			$json_item .= "\"category\":[0], ";
			$json_item .= "\"color\": \"".$color."\", ";
			$json_item .= "\"icon\": \"".$icon."\", ";
			// $json_item .= "\"thumb\": \"".$single['thumb']."\", ";
			$json_item .= "\"timestamp\": \"0\", ";
			$json_item .= "\"count\": \"" . 1 . "\"";
			$json_item .= "},";
			$json_item .= "\"geometry\": {";
			$json_item .= "\"type\":\"Point\", ";
			$json_item .= "\"coordinates\":[" . $lon . ", " . $lat . "]";
			$json_item .= "}";
			$json_item .= "}";

			array_push($json_array, $json_item);
		}

		$json = implode(",", $json_array);
		
		// 
		// E.Kala July 27, 2011
		// @todo Parking this geometry business for review
		// 
		
		// if (count($geometry_array))
		// {
		// 	$json = implode(",", $geometry_array).",".$json;
		// }
		
		header('Content-type: application/json; charset=utf-8');
		$controller->template->json = '{"type":"FeatureCollection","features":['.$json.']}';

    }//end cluster method
	    
    
  
  
  
  
  
  
  
  
     /**************************************************************
     * Retrieve timeline JSON
     * $on_the_back_end is used to set if the user is looking at this on the backend or not
     */
    public static function json_timeline( $controller, 							 
								$on_the_back_end = true,
								$extra_where_text = "",
                                $joins = array(),
                                $custom_category_to_table_mapping = array())
    {
    	$category_ids = array('0');
    	
    	if (isset($_GET['c']) AND is_array($_GET['c']))
    	{
    		$category_ids = array();
    		//make sure we only hanlde numeric cat ids
    		foreach($_GET['c'] as $cat)
    		{
    			if(is_numeric($cat))
    			{
    				$category_ids[] = $cat;
    			}
    		}
    	}
    	
    	
		$is_all_categories = false;
		If(count($category_ids) == 0 || $category_ids[0] == '0')
		{
			$is_all_categories = true;
		}

        $controller->auto_render = FALSE;
        $db = new Database();
	
	
	    $interval = (isset($_GET["i"]) AND !empty($_GET["i"])) ? $_GET["i"] : "month";


        // Get the Counts
        $select_date_text = "DATE_FORMAT(incident_date, '%Y-%m-01')";
        $groupby_date_text = "DATE_FORMAT(incident_date, '%Y%m')";
        if ($interval == 'day')
        {
            $select_date_text = "DATE_FORMAT(incident_date, '%Y-%m-%d')";
            $groupby_date_text = "DATE_FORMAT(incident_date, '%Y%m%d')";
        }
        elseif ($interval == 'hour')
        {
            $select_date_text = "DATE_FORMAT(incident_date, '%Y-%m-%d %H:%M')";
            $groupby_date_text = "DATE_FORMAT(incident_date, '%Y%m%d%H')";
        }
        elseif ($interval == 'week')
        {
            $select_date_text = "STR_TO_DATE(CONCAT(CAST(YEARWEEK(incident_date) AS CHAR), ' Sunday'), '%X%V %W')";
            $groupby_date_text = "YEARWEEK(incident_date)";
        }

	
        //more than one color
    	if(count($category_ids) == 1 AND intval($category_ids[0]) == 0 )
		{
			$colors = array(Kohana::config('settings.default_map_all'));
		}		
		else 
		{	
			//more than one color
			$colors = array();
			foreach($category_ids as $cat)
			{
				$colors[] = ORM::factory('category', $cat)->category_color;
			}
		}	
		$color = self::merge_colors($colors);
	
        $graph_data = array();
        $graph_data[0] = array();
        $graph_data[0]['label'] = "Category Title"; //is this used for anything?        
        $graph_data[0]['color'] = '#'.$color;
        $graph_data[0]['data'] = array();

        
        
        
        
        ////////////////////////////////////////////////////////////////////////////////////
        //start the process of getting ready to grab incidents
        ////////////////////////////////////////////////////////////////////////////////////
        
        // Get Zoom Level
        $zoomLevel = (isset($_GET['z']) AND !empty($_GET['z'])) ?
        (int) $_GET['z'] : 8;
        
        //$distance = 60;
        $distance = (10000000 >> $zoomLevel) / 100000;
        
         
        // Category ID
        $category_ids = (isset($_GET['c']) AND is_array($_GET['c'])) ? $_GET['c'] : array(0);
        
        // Start date
        $start_date = (isset($_GET['s']) AND intval($_GET['s']) > 0) ? intval($_GET['s']) : NULL;
        
        // End date
        $end_date = (isset($_GET['e']) AND intval($_GET['e']) > 0) ? intval($_GET['e']) : NULL;
        
        //Logical operator
        $logical_operator = isset($_GET['lo'])  ? $_GET['lo'] : 'or';
        
        // SouthWest Bound
        $southwest = (isset($_GET['sw']) AND !empty($_GET['sw'])) ?
        $_GET['sw'] : "0";
        
        $northeast = (isset($_GET['ne']) AND !empty($_GET['ne'])) ?
        $_GET['ne'] : "0";
        
        
        //approve filter
        if($on_the_back_end)
        {
        	//figure out if we're showing unapproved stuff or what.
        	if (isset($_GET['u']) AND !empty($_GET['u']))
        	{
        		$show_unapproved = (int) $_GET['u'];
        	}
        	$approved_text = "";
        	if($show_unapproved == 1)
        	{
        		$approved_text = "incident.incident_active = 1 ";
        	}
        	else if ($show_unapproved == 2)
        	{
        		$approved_text = "incident.incident_active = 0 ";
        	}
        	else if ($show_unapproved == 3)
        	{
        		$approved_text = " (incident.incident_active = 0 OR incident.incident_active = 1) ";
        	}
        }
        else
        {
        	$approved_text = "incident.incident_active = 1 ";
        	$show_unapproved = 1;
        }
        
        //get color
        if(count($category_ids) == 1 AND intval($category_ids[0]) == 0 )
        {
        	$colors = array(Kohana::config('settings.default_map_all'));
        }
        else
        {
        	//more than one color
        	$colors = array();
        	foreach($category_ids as $cat)
        	{
        		$colors[] = ORM::factory('category', $cat)->category_color;
        	}
        }
        $color = self::merge_colors($colors);
        
        //make the filter text
        $filter = "";
        $filter .= ($start_date) ?
        " AND incident.incident_date >= '" . date("Y-m-d H:i:s", $start_date) . "'" : "";
        $filter .= ($end_date) ?
        " AND incident.incident_date <= '" . date("Y-m-d H:i:s", $end_date) . "'" : "";
        
        if ($southwest AND $northeast)
        {
        	list($latitude_min, $longitude_min) = explode(',', $southwest);
        	list($latitude_max, $longitude_max) = explode(',', $northeast);
        
        	$filter .= " AND location.latitude >=".(float) $latitude_min.
        	" AND location.latitude <=".(float) $latitude_max;
        	$filter .= " AND location.longitude >=".(float) $longitude_min.
        	" AND location.longitude <=".(float) $longitude_max;
        }
        
        
        // Fetch the incidents using the specified parameters
        $incidents = adminmap_reports::get_reports_list_by_cat($category_ids,
        		$approved_text. ' ' .$filter ,
        		$logical_operator,
        		"incident.id",
        		"asc");
        ////////////////////////////////////////////////////////////////////////////////////
        //dont grabing incidents
        ////////////////////////////////////////////////////////////////////////////////////
        
        
        
        
        
        
        
        
	
	
	$approved_IDs_str = "('-1')";
	if(count($incidents) > 0)
	{
		$i = 0;
		$approved_IDs_str = "(";
		foreach($incidents as $incident)
		{
			$i++;
			$approved_IDs_str = ($i > 1) ? $approved_IDs_str.', ' : $approved_IDs_str;
			$approved_IDs_str = $approved_IDs_str."'".$incident->id."'";
		}
		$approved_IDs_str = $approved_IDs_str.") ";
	}

        $query = 'SELECT UNIX_TIMESTAMP('.$select_date_text.') AS time, COUNT(id) AS number FROM '.adminmap_helper::$table_prefix.'incident WHERE incident.id in'.$approved_IDs_str.' GROUP BY '.$groupby_date_text;
	$query = $db->query($query);

        foreach ( $query as $items )
        {
            array_push($graph_data[0]['data'],
                array($items->time * 1000, $items->number));
        }

        echo json_encode($graph_data);
    }


   
  
  
  
  /**
	 * Get Geometry JSON
	 * @param int $incident_id
	 * @param string $incident_title
	 * @param int $incident_date
	 * @return array $geometry
	 */
	private static function _get_geometry($incident_id, $incident_title, $incident_date, $on_the_back_end, $color, $link_target = "_self")
	{
		$geometry = array();
		if ($incident_id)
		{
			$db = new Database();
			// Get Incident Geometries via SQL query as ORM can't handle Spatial Data
			$sql = "SELECT id, AsText(geometry) as geometry, geometry_label, 
				geometry_comment, geometry_color, geometry_strokewidth FROM ".self::$table_prefix."geometry 
				WHERE incident_id=".$incident_id;
			$query = $db->query($sql);
			$wkt = new Wkt();

			foreach ( $query as $item )
			{
				$geom = $wkt->read($item->geometry);
				$geom_array = $geom->getGeoInterface();

				$json_item = "{";
				$json_item .= "\"type\":\"Feature\",";
				$json_item .= "\"properties\": {";
				$json_item .= "\"id\": \"".$incident_id."\", ";
				$json_item .= "\"feature_id\": \"".$item->id."\", ";

				$title = ($item->geometry_label) ? 
					utf8tohtml::convert($item->geometry_label,TRUE) : 
					utf8tohtml::convert($incident_title,TRUE);
					
				$fillcolor = ($item->geometry_color) ? 
					utf8tohtml::convert($item->geometry_color,TRUE) : $color;
					
				$strokecolor = ($item->geometry_color) ? 
					utf8tohtml::convert($item->geometry_color,TRUE) : $color;
					
				$strokewidth = ($item->geometry_strokewidth) ? $item->geometry_strokewidth : "3";

				if($on_the_back_end)
				{
					$json_item .= "\"name\":\"" . str_replace(chr(10), ' ', str_replace(chr(13), ' ', "<a href='" . url::base() . "admin/reports/edit/" . $incident_id . "'>".$title."</a>")) . "\",";
				}
				else
				{
					$json_item .= "\"name\":\"" . str_replace(chr(10), ' ', str_replace(chr(13), ' ', "<a target='".$link_target."' href='" . url::base() . "reports/view/" . $incident_id . "'>".$title."</a>")) . "\",";
				}

				$json_item .= "\"description\": \"" . utf8tohtml::convert($item->geometry_comment,TRUE) . "\", ";
				$json_item .= "\"color\": \"" . $fillcolor . "\", ";
				$json_item .= "\"strokecolor\": \"" . $strokecolor . "\", ";
				$json_item .= "\"strokewidth\": \"" . $strokewidth . "\", ";
				$json_item .= "\"link\": \"".url::base()."reports/view/".$incident_id."\", ";
				$json_item .= "\"category\":[0], ";
				$json_item .= "\"timestamp\": \"" . strtotime($incident_date) . "\"";
				$json_item .= "},\"geometry\":".json_encode($geom_array)."}";
				$geometry[] = $json_item;
			}
		}
		
		return $geometry;
	}
  
  
  
  
  
  /**
     * Calculate the center of a cluster of markers
     * @param array $cluster
     * @return array - (center, southwest bound, northeast bound)
     */
    private static function _calculateCenter($cluster)
    {
    	// Calculate average lat and lon of clustered items
		$south = 0;
		$west = 0;
		$north = 0;
		$east = 0;

		$lat_sum = $lon_sum = 0;
		foreach ($cluster as $marker)
		{
			if (!$south)
			{
				$south = $marker['latitude'];
			}
			elseif ($marker['latitude'] < $south)
			{
				$south = $marker['latitude'];
			}

			if (!$west)
			{
				$west = $marker['longitude'];
			}
			elseif ($marker['longitude'] < $west)
			{
				$west = $marker['longitude'];
			}

			if (!$north)
			{
				$north = $marker['latitude'];
			}
			elseif ($marker['latitude'] > $north)
			{
				$north = $marker['latitude'];
			}

			if (!$east)
			{
				$east = $marker['longitude'];
			}
			elseif ($marker['longitude'] > $east)
			{
				$east = $marker['longitude'];
			}

			$lat_sum += $marker['latitude'];
			$lon_sum += $marker['longitude'];
		}
		$lat_avg = $lat_sum / count($cluster);
		$lon_avg = $lon_sum / count($cluster);

		$center = $lon_avg.",".$lat_avg;
		$sw = $west.",".$south;
		$ne = $east.",".$north;

		return array(
			"center"=>$center,
			"sw"=>$sw,
			"ne"=>$ne
		);
	}//end function
    
    
	


}//end class adminmap_core


	adminmap_helper_Core::init();



