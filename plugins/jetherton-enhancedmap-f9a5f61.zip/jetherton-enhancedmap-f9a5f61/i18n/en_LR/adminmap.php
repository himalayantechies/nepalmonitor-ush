<?php defined('SYSPATH') or die('No direct script access.');
/**
 * Liberian English translation of the Admin Map plugin
 *
 * PHP version 5
 * LICENSE: This source file is subject to LGPL license
 * that is available through the world-wide-web at the following URI:
 * http://www.gnu.org/copyleft/lesser.html
 * @author     John Etherton <john@ethertontech.com>
 * @author     Carter Draper <carjimdra@gmail.com>
 * @author     Kpetermeni Siakor <tksiakor@gmail.com> 
 * @package    Admin Map, Ushahidi Plugin - https://github.com/jetherton/adminmap
 */

	$lang = array(
	'big_map_main_menu_tab' => 'The Map, It Big-O',
	'boolean_operators' => 'Boolean Operators:',	
	'status_filters' => 'choose a specific status'
	);
?>
