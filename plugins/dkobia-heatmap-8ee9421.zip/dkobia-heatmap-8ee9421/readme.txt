=== About ===
name: Heatmap
website: http://www.ushahidi.com
description: Generate a Heatmap from Active Reports
version: 0.8
requires: 2.0
tested up to: 2.5
author: David Kobia
author website: 

== Description ==
Generate a Heatmap from Active Reports

== Installation ==
1. Copy the entire /heatmap/ directory into your /plugins/ directory.
2. Activate the plugin.

== Changelog ==