<br/>
<ul class="category-filters">
	<li>
		<a href="<?php echo url::site(); ?>heatmap">
			<span><img src="<?php echo url::base() ?>plugins/heatmap/media/heatmap/images/fire.png" style="float:left;padding-right:5px;"></span>
			<span class="category-title" style="line-height:22px;"><?php echo Kohana::lang('heatmap.heatmap'); ?></span>
		</a>
	</li>
</ul>