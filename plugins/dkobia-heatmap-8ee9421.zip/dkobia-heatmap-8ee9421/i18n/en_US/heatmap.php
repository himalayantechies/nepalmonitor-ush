<?php
	$lang = array(
	'home' => 'Home',
	'heatmap' => 'Heat Map',
	);
?>
