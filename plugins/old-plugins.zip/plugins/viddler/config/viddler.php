<?php defined('SYSPATH') OR die('No direct access allowed.');
	$config['username'] = '';
	$config['password'] = '';
	$config['api_key'] = '';
	$config['maximum_filesize'] = '2097152'; // in bytes (2 megabytes = 2097152 bytes)
?>