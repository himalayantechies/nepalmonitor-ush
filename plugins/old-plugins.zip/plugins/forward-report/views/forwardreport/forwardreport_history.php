<li>
	<?php
		echo  $user . " forwarded this report to " .$instance_name. " on " . $date;
	?>
</li>
