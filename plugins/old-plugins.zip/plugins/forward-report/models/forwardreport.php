<?php defined('SYSPATH') or die('No direct script access.');
/**
 * Forward Reports - Database Model
 *
 * @author	   John Etherton
 * @package	   Forward Reports
 */

class forwardreport_Model extends ORM
{
	
	// Database table name
	protected $table_name = 'forwardreports';
}
