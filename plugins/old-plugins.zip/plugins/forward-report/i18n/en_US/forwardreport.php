<?php
	$lang = array(
		'forwardreport'=>"Forward Report",
		'forwardreportto'=>"Forward Report To Instance",
		'forward'=>'Forward',
		'forwardreport_description'=> 'Set which Ushahidi instances you want to be able to forward messages to, and if they should forward to a simple group',
		'name'=>'Name',
		'url'=>'URL',
		'simplegroup_name'=>'Simple Group Name',
		'delete'=>'Delete',
		'actions'=>'Actions',
		'edit'=>'Edit',
		'error_forwarding'=>'Error forwarding report. Please try again',
	);
?>
