=== About ===
name: Hide Time
website: https://github.com/jetherton/hidetime
description: Gives users the ability to hide time for reports that may not have occured at a finite moment
version: 0.5
requires: 2.0
tested up to: 2.1
author: John Etherton
author website: http://johnetherton.com

== Description ==
Creates a check box allowing users to hide the time, not the date, of a report. Useful when reports are about events that may have a fuzzy time component


== Installation ==
1. Copy the entire /hidetime/ directory into your /plugins/ directory.
2. Activate the plugin.

== Changelog ==
