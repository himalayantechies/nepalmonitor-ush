

//Java script added by the hide time plugin to make sure that the time is hidden
$().ready(
	function(){ 
		$('span.r_date' ).css("display", "none");
		
		$('#datenotime' ).css("display", "none");
	});
	
