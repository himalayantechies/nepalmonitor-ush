

//Java script added by the hide time plugin to make sure that the time is hidden
//window.onload = function() {alert("ran baby");}

$().ready(
	function(){ 
		$('#datetime_edit > .time').css("display", "none");
	});
	
