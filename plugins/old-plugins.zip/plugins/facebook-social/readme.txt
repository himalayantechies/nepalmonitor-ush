=== About ===
name: Facebook Social
website: http://www.ushahidi.com
description: Allow users to comment on reports via Facebook
version: 0.6
requires: 2.0
tested up to: 2.0
author: David Kobia
author website: http://www.dkfactor.com

== Description ==



== Installation ==

== Changelog ==

Monday, May 9, 2011
* Fixed error that cropped up when Facebook changed their API
   - Brian Herbert