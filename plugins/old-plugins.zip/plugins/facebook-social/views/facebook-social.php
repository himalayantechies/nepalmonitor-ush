<div class="content">

<div id="fb-root"></div><script src="http://connect.facebook.net/en_US/all.js#xfbml=1"></script><fb:comments href="<?php echo url::base().trim($_SERVER['REDIRECT_URL'],'/'); ?>" num_posts="2" width="530"></fb:comments>

</div>