INSERT INTO `scheduler` (`id`,
`scheduler_name`,`scheduler_last`,`scheduler_weekday`,`scheduler_day`,`scheduler_hour`,`scheduler_minute`,`scheduler_controller`,`scheduler_active`) VALUES
('','Sharing','0','-1','-1','-1','-1','s_sharing','1');
