=== About ===
name: Find Location
website: http://apps.ushahidi.com
description: Improves the functionality of the "Find Location" Button.
version: 1.0
requires: 2.1
tested up to: 2.1
author: John Etherton
author website: http://johnetherton.com

== Description ==
Improves the functionality of the "Find Location" Button. This plugin will replace the functionality of the reports/geocode controller.

* Lets you set the region/country results are biased towards
* Lets you add text to the end of a search. For instance you could add ", Mexico" so that all searches are "something, Mexico"
* Lets you bound your searches to a given bounding box specified by NW lat,lon SE lat,lon