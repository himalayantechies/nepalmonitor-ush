<?php
	$lang = array(
		'region_code'=>array('default'=>'Region code can be no more than 3 characters long'),
		'append_to_google'=>array('default'=>'The Append To Google string can be no more than 200 characters long'),
		'goenames_username'=>array('default'=>'The GeoNames Username can be no more than 200 characters long')
	);
?>
