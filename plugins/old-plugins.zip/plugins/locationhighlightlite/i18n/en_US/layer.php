<?php
/**
 *  Language file
 *
 */

	$lang = array(
		'file'=>array('default'=>'File must be a KML or KMZ file'),
		'name'=>array('default'=>'Name must be between 3 and 80 characters long'),
	);


