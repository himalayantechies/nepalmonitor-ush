<?php defined('SYSPATH') or die('No direct script access.');
/**
 * Time Span - Database Model
 *
 * @author	   John Etherton
 * @package	   Time Span
 */

class timespan_Model extends ORM
{
	
	// Database table name
	protected $table_name = 'timespan';
}
