<?php defined('SYSPATH') or die('No direct script access.');
/**
 * Liberian English translation of the Admin Map plugin
 *
 * @author     John Etherton <john@ethertontech.com>
 * @author     Carter Draper <carjimdra@gmail.com>
 * @author     Kpetermeni Siakor <tksiakor@gmail.com> 
 * @package    Enhanced Map, Ushahidi Plugin - https://github.com/jetherton/enhancedmap
 */


	$lang = array(
	'big_map_main_menu_tab' => 'The Map, It Big-O',
	'boolean_operators' => 'Boolean Operators:',	
	'status_filters' => 'choose a specific status'
	);
?>
