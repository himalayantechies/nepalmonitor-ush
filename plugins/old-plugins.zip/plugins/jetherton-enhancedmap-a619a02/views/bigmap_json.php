<?php defined('SYSPATH') or die('No direct script access.');
/**
 * View for the big map json 
 * 
 *
 * @author     John Etherton <john@ethertontech.com>
 * @package    Enhanced Map, Ushahidi Plugin - https://github.com/jetherton/enhancedmap
 */
?>
{"type": "FeatureCollection","features": [<?php echo $json; ?>]}

