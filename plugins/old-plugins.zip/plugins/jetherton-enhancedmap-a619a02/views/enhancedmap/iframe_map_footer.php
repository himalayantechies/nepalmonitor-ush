<?php defined('SYSPATH') or die('No direct script access.');
/**
 * Footer for the iFrame map
 * 
 *
 *
 * @author     John Etherton <john@ethertontech.com>
 * @package    Enhanced Map, Ushahidi Plugin - https://github.com/jetherton/enhancedmap
 */
?>
	<?php echo $google_analytics; ?>
</body>

</html>