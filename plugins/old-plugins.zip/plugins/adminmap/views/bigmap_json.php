{"type": "FeatureCollection","features": [<?php echo $json; ?>]}

