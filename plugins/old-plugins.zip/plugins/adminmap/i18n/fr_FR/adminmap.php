<?php defined('SYSPATH') or die('No direct script access.');
/**
 * Very basic French translation of the Admin Map plugin
 *
 * PHP version 5
 * LICENSE: This source file is subject to LGPL license
 * that is available through the world-wide-web at the following URI:
 * http://www.gnu.org/copyleft/lesser.html
 * @author     John Etherton <john@ethertontech.com>
 * @package    Admin Map, Ushahidi Plugin - https://github.com/jetherton/adminmap
 */

	$lang = array(
	'big_map_main_menu_tab' => 'Carte de Grande',
	'boolean_operators' => 'Operateurs booleens',
	'status_filters' => 'Filtres Statut',
	);
?>
