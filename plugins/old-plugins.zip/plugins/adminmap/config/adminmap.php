<?php defined('SYSPATH') or die('No direct script access.');
/**
 * Show embed code on main page
 */
$config['show_embed_code'] = TRUE;