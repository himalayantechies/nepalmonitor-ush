<?php
	$lang = array(
		'error'=>"ERROR"
	);
?>
