

<div class="row">
	<h4><?php echo Kohana::lang('simplegroups.reporter');?></h4>
	<span style="font-size:11pt;"><?php echo Kohana::lang('simplegroups.from');?>
	<strong> <?php echo "$name -- $org"; ?> </strong>
	</span>
</div>