<div style="color:#9b0000; font-size:10pt;">
	<ul class="info">
		<li class="none-separator">
			<?php echo "Number belongs to: <strong>$name -- $org</strong>"; ?>
		</li>
	<ul/>
</div>