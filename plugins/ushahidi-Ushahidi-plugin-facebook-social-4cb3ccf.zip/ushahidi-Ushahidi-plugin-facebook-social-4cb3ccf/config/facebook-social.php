<?php defined('SYSPATH') or die('No direct script access.');

/**
* FACEBOOK SOCIAL CONFIGURATION
*/

/**
 * Facebook APP ID
 * Get a new one at: http://www.facebook.com/developers/createapp.php
 */
$config['facebook_app_id'] = "128105260546180";