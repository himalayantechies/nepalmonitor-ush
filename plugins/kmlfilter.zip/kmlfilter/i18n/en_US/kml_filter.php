<?php
$lang = array(
	'layer' => 'Layer',
);
?>