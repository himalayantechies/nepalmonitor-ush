<?php
	$lang = array(
	);
