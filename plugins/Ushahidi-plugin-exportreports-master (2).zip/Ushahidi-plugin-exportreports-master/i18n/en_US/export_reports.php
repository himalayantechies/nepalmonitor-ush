<?php
$lang = array(
	'csv' => 'CSV',
	'export_csv' => 'Export in CSV',
	'export_kml' => 'Export in KML',
	'export_xml' => 'Export in XML',
	'kml' => 'KML',
	'xml' => 'XML',
);
?>