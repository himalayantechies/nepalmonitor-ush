<?php defined('SYSPATH') or die('No direct script access.');
?>
<p>
	<a href="#" class="export-button" exptype="csv"><?php echo Kohana::lang('export_reports.export_csv'); ?></a>
	<a href="#" class="export-button" exptype="xml"><?php echo Kohana::lang('export_reports.export_xml'); ?></a>
</p>